-- Movie Rentals --

- Landing Page

 - Client (Section)
  |
  - Sign In & [POST]
  - Sign Up [POST]
   |
   - Client Home [GET]
   - Movie Page [GET]
   - Movie Check Out [POST]
   |
   - Timeline Page [GET]
   - Friends Page [GET]
   |
   - Account [GET]
    - My Movies [GET]
    - Settings [POST]

 - Admin (Section)
  - Sign In [POST]
   |
   - Dashboard [GET]
   - Movie List [GET]
    |
    - Edit List [POST]
   - Account List [GET]
    |
    - Edit Accounts [POST]
   
